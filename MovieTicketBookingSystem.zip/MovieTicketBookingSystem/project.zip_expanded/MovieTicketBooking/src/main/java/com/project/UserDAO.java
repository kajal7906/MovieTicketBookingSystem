package com.project;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import java.util.List;

public class UserDAO {

    // Save a user to the database
    public void saveUser(User user) {
        Transaction transaction = null;
        try (SessionFactory factory= new Configuration().configure().buildSessionFactory();
        	Session session = factory.openSession()) {
            transaction = session.beginTransaction(); // Start a transaction
            session.save(user); // Save the user object to the database
            transaction.commit(); // Commit the transaction
        } catch (Exception e) {
            if (transaction != null) transaction.rollback(); // Roll back if there's an error
            e.printStackTrace();
        }
    }

    // Get a user by ID
    public User getUserById(int userId) {
        try (SessionFactory factory= new Configuration().configure().buildSessionFactory();
        	Session session = factory.openSession()) {
            return session.get(User.class, userId); // Retrieve user by primary key
        }
    }

    // Get all users
    public List<User> getAllUsers() {
        try (SessionFactory factory= new Configuration().configure().buildSessionFactory();
        	Session session = factory.openSession()) {
            return session.createQuery("from User", User.class).list(); // Retrieve all users
        }
    }

       
}
