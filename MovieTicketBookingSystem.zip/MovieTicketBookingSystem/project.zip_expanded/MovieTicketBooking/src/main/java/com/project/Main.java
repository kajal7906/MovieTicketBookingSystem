package com.project;

import java.util.List;
import java.util.Scanner;

public class Main {

    private static final UserService userService = new UserService();
    private static final MovieService movieService = new MovieService();
    private static final ShowtimeService showtimeService = new ShowtimeService();
    private static final SeatService seatService = new SeatService();
    private static final BookingService bookingService = new BookingService();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n===== Movie Ticket Booking System =====");
            System.out.println("1. Add User");
            System.out.println("2. Add Movie");
            System.out.println("3. Add Showtime");
            System.out.println("4. List All Movies");
            System.out.println("5. List Showtimes for a Movie");
            System.out.println("6. Book a Seat");
            System.out.println("7. View Bookings for a User");
            System.out.println("8. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1 : addUser(scanner);
                		break;
                		
                case 2 : addMovie(scanner);
        		        break;

                case 3 : addShowtime(scanner);
        				break;

                case 4 : listAllMovies();
        				break;

                case 5 : listShowtimes(scanner);
        				break;

                case 6 : bookSeat(scanner);
                		break;

                case 7 : viewBookings(scanner);
                case 8 : {
                    System.out.println("Thank you!");
                    scanner.close();
                    System.exit(0);
                }
                default : System.out.println("Invalid choice! Please try again.");
            }
        }
    }

    private static void addUser(Scanner scanner) {
    	User user= new User();
        System.out.print("Enter Username: ");
        String username = scanner.nextLine();
        System.out.print("Enter Password: ");
        String password = scanner.nextLine();
        System.out.print("Enter Email: ");
        String email = scanner.nextLine();
        user.getUserId();
        user.setUsername(username);
        user.setPassword(password);
        user.setEmail(email);
        
        userService.addUser(username, password, email);
        System.out.println("User added successfully!");
    }

    private static void addMovie(Scanner scanner) {
        System.out.print("Enter Movie Title: ");
        String title = scanner.nextLine();
        System.out.print("Enter Genre: ");
        String genre = scanner.nextLine();

        movieService.addMovie(title, genre);
        System.out.println("Movie added successfully!");
    }

    private static void addShowtime(Scanner scanner) {
        System.out.print("Enter Movie ID: ");
        int movieId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        Movie movie = movieService.getMovieById(movieId);

        System.out.println("Retrieved Movie: " + movie);
        
        if (movie == null) {
            System.out.println("Invalid Movie ID!");
            return;
        }

        System.out.print("Enter Date (YYYY-MM-DD): ");
        String date = scanner.nextLine();
        System.out.print("Enter Time (HH:MM): ");
        String time = scanner.nextLine();

        showtimeService.addShowtime(movie, date, time);
        System.out.println("Showtime added successfully!");
    }

    private static void listAllMovies() {
        List<Movie> movies = movieService.getAllMovies();

        if (movies.isEmpty()) {
            System.out.println("No movies available.");
        } else {
            System.out.println("\nMovies:");
            movies.forEach(System.out::println);
        }
    }

    private static void listShowtimes(Scanner scanner) {
        System.out.print("Enter the Movie ID to see showtimes: ");
        int movieId = scanner.nextInt();
        List<Showtime> showtimes = showtimeService.getShowtimesByMovieId(movieId);

        if (showtimes.isEmpty()) {
            System.out.println("No showtimes available for this movie.");
        } else {
            System.out.println("\nShowtimes:");
            showtimes.forEach(System.out::println);
        }
    }

    private static void bookSeat(Scanner scanner) {
        System.out.print("Enter User ID: ");
        int userId = scanner.nextInt();
        System.out.print("Enter Showtime ID: ");
        int showtimeId = scanner.nextInt();
        System.out.print("Enter Seat Number: ");
        int seatNumber = scanner.nextInt();
        System.out.print("Enter Price: ");
        double price = scanner.nextDouble();

        boolean success = bookingService.bookSeat(userId, showtimeId, seatNumber, price);

        if (success) {
            System.out.println("Seat booked successfully!");
        } else {
            System.out.println("Seat booking failed. Either the seat is unavailable or the details are invalid.");
        }
    }

    private static void viewBookings(Scanner scanner) {
        System.out.print("Enter User ID to view bookings: ");
        int userId = scanner.nextInt();

        List<Booking> bookings = bookingService.getBookingsForUser(userId);

        if (bookings.isEmpty()) {
            System.out.println("No bookings found for this user.");
        } else {
            System.out.println("\nBookings:");
            bookings.forEach(System.out::println);
        }
    }
}

