package com.project;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import java.util.List;

public class ShowtimeDAO {

    public void addShowtime(Showtime showtime) {
        Transaction transaction = null;
        try (SessionFactory factory= new Configuration().configure().buildSessionFactory();
            	Session session = factory.openSession()) {
            transaction = session.beginTransaction();
            session.save(showtime);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
    }

    public Showtime getShowtimeById(int showtimeId) {
        try (SessionFactory factory= new Configuration().configure().buildSessionFactory();
            	Session session = factory.openSession()) {
            return session.get(Showtime.class, showtimeId);
        }
    }

    public List<Showtime> getShowtimesByMovieId(int movieId) {
        try (SessionFactory factory= new Configuration().configure().buildSessionFactory();
            	Session session = factory.openSession()) {
            return session.createQuery("from Showtime where movie.movieId = :movieId", Showtime.class)
                    .setParameter("movieId", movieId)
                    .list();
        }
    }

    public List<Showtime> getAllShowtimes() {
        try (SessionFactory factory= new Configuration().configure().buildSessionFactory();
            	Session session = factory.openSession()) {
            return session.createQuery("from Showtime", Showtime.class).list();
        }
    }
}

