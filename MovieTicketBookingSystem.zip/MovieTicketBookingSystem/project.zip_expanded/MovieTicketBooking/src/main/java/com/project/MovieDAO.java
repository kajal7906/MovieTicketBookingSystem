package com.project;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import java.util.List;

public class MovieDAO {

    // Save a movie to the database
    public void addMovie(Movie movie) {
        Transaction transaction = null;
        try (SessionFactory factory= new Configuration().configure().buildSessionFactory();
            Session session = factory.openSession()){
            transaction = session.beginTransaction();
            session.save(movie);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
    }

    // Get a movie by ID
    public Movie getMovieById(int movieId) {
        try (SessionFactory factory= new Configuration().configure().buildSessionFactory();
            	Session session = factory.openSession()) {
            return session.get(Movie.class, movieId);
        }
    }

    // Get all movies
    public List<Movie> getAllMovies() {
        try (SessionFactory factory= new Configuration().configure().buildSessionFactory();
            	Session session = factory.openSession()) {
            return session.createQuery("from Movie", Movie.class).list();
        }
    }

}

