package com.project;

import java.util.List;

public class BookingService {

    private final BookingDAO bookingDAO = new BookingDAO();
    private final SeatDAO seatDAO = new SeatDAO();
    private final UserDAO userDAO = new UserDAO();
    private final ShowtimeDAO showtimeDAO = new ShowtimeDAO();

    // Book a seat
    public boolean bookSeat(int userId, int showtimeId, int seatNumber, double price) {
        Seat seat = seatDAO.getSeatByShowtimeAndNumber(showtimeId, seatNumber);

        if (seat != null && seat.isAvailable()) {
            seat.setAvailable(false);
            seatDAO.saveSeat(seat);

            User user = userDAO.getUserById(userId);
            Showtime showtime = showtimeDAO.getShowtimeById(showtimeId);

            Booking booking = new Booking(user, showtime, seat, price);
            bookingDAO.saveBooking(booking);
            return true;
        }
        return false;
    }

    // List bookings for a user
    public List<Booking> getBookingsForUser(int userId) {
        return bookingDAO.getAllBookingsForUser(userId);
    }
}


