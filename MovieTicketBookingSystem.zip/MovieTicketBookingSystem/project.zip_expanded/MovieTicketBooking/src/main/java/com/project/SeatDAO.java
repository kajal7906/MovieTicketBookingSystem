package com.project;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class SeatDAO {

    public static void saveSeat(Seat seat) {
        Transaction transaction = null;
        try (SessionFactory factory= new Configuration().configure().buildSessionFactory();
            	Session session = factory.openSession()) {
            transaction = session.beginTransaction();
            session.update(seat);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
    }

    public Seat getSeatById(int seatId) {
        try (SessionFactory factory= new Configuration().configure().buildSessionFactory();
            	Session session = factory.openSession()) {
            return session.get(Seat.class, seatId);
        }
    }

    public Seat getSeatByShowtimeAndNumber(int showtimeId, int seatNumber) {
        try (SessionFactory factory= new Configuration().configure().buildSessionFactory();
            	Session session = factory.openSession()) {
            return session.createQuery("from Seat where showtime.showtimeId = :showtimeId and seatNumber = :seatNumber", Seat.class)
                    .setParameter("showtimeId", showtimeId)
                    .setParameter("seatNumber", seatNumber)
                    .uniqueResult();
        }
    }

    public List<Seat> getAllSeatsForShowtime(int showtimeId) {
        try (SessionFactory factory= new Configuration().configure().buildSessionFactory();
            	Session session = factory.openSession()) {
            return session.createQuery("from Seat where showtime.showtimeId = :showtimeId", Seat.class)
                    .setParameter("showtimeId", showtimeId)
                    .list();
        }
    }
    
    public void updateSeat(Seat seat) {
        Transaction transaction = null;
        try (SessionFactory factory= new Configuration().configure().buildSessionFactory();
            	Session session = factory.openSession()) {
            transaction = session.beginTransaction();
            session.update(seat);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
    }

}


