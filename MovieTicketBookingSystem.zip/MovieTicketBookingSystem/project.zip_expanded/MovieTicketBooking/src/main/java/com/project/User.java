package com.project;

import javax.persistence.*;

@Entity
@Table(name = "users")
public class User {

 @Id
 @GeneratedValue(strategy = GenerationType.IDENTITY) 
 // Instructs the database to automatically generate unique IDs (auto-increment)
 private int userId;

 @Column(nullable = false, unique = true) 
 // Maps this field to a column, ensures it's not null and unique (e.g., for usernames)
 private String username;

 @Column(nullable = false) 
 private String password;

 @Column(nullable = false, unique = true) 
 private String email;




 public int getUserId() {
     return userId;
 }

 public void setUserId(int userId) {
     this.userId = userId;
 }

 public String getUsername() {
     return username;
 }

 public void setUsername(String username) {
     this.username = username;
 }

 public String getPassword() {
     return password;
 }

 public void setPassword(String password) {
     this.password = password;
 }

 public String getEmail() {
     return email;
 }

 public void setEmail(String email) {
     this.email = email;
 }
 
 // Default constructor
 public User() {}

 public User(String username, String password, String email) {
     this.username = username;
     this.password = password;
     this.email = email;
 }

 @Override
 public String toString() {
     // Returns a readable string representation of the user object
     return "User{" +
             "userId=" + userId +
             ", username='" + username + '\'' +
             ", email='" + email + '\'' +
             '}';
 }
}

