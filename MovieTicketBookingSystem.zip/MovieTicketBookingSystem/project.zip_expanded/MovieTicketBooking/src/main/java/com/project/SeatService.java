package com.project;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class SeatService {

    private final SeatDAO seatDAO = new SeatDAO();

    // Add a seat for a showtime
    public void addSeat(Showtime showtime, int seatNumber) {
        Seat seat = new Seat(showtime, seatNumber, true);
        seatDAO.saveSeat(seat);
    }

    // Get a specific seat by showtime and seat number
    public Seat getSeatByShowtimeAndNumber(int showtimeId, int seatNumber) {
        try (SessionFactory factory= new Configuration().configure().buildSessionFactory();
            	Session session = factory.openSession()) {
            return session.createQuery(
                "FROM Seat WHERE showtime.id = :showtimeId AND seatNumber = :seatNumber", Seat.class)
                .setParameter("showtimeId", showtimeId)
                .setParameter("seatNumber", seatNumber)
                .uniqueResult();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }


    // List all seats for a showtime
    public List<Seat> getAllSeatsForShowtime(int showtimeId) {
        return seatDAO.getAllSeatsForShowtime(showtimeId);
    }
}

