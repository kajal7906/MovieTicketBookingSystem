package com.project;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class BookingDAO {

    public void saveBooking(Booking booking) {
        Transaction transaction = null;
        try (SessionFactory factory= new Configuration().configure().buildSessionFactory();
            	Session session = factory.openSession()) {
            transaction = session.beginTransaction();
            session.save(booking);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
    }

    public Booking getBookingById(int bookingId) {
        try (SessionFactory factory= new Configuration().configure().buildSessionFactory();
            	Session session = factory.openSession()) {
            return session.get(Booking.class, bookingId);
        }
    }

    public List<Booking> getAllBookingsForUser(int userId) {
        try (SessionFactory factory= new Configuration().configure().buildSessionFactory();
            	Session session = factory.openSession()) {
            return session.createQuery("from Booking where user.userId = :userId", Booking.class)
                    .setParameter("userId", userId)
                    .list();
        }
    }
}


