package com.project;

import java.util.List;

public class UserService {

    private final UserDAO userDAO = new UserDAO();

    // Add a new user
    public void addUser(String username, String password, String email) {
        User user = new User(username, password, email);
        userDAO.saveUser(user);
    }

    // Get user by ID
    public User getUserById(int userId) {
        return userDAO.getUserById(userId);
    }

    // List all users
    public List<User> getAllUsers() {
        return userDAO.getAllUsers();
    }
}


