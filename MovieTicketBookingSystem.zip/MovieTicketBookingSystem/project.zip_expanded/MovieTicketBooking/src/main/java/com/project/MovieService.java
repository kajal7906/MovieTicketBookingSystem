package com.project;

import java.util.List;

public class MovieService {

    private final MovieDAO movieDAO = new MovieDAO();

    // Add a new movie
    public void addMovie(String title, String genre) {
        Movie movie = new Movie(title, genre);
        movieDAO.addMovie(movie);
    }

    // Get movie by ID
    public Movie getMovieById(int movieId) {
        return movieDAO.getMovieById(movieId);
    }

    // List all movies
    public List<Movie> getAllMovies() {
        return movieDAO.getAllMovies();
    }
}


