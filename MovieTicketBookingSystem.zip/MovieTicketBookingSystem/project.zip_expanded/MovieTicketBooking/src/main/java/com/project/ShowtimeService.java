package com.project;

import java.util.List;

public class ShowtimeService {
    private final ShowtimeDAO showtimeDAO = new ShowtimeDAO();

    // Fetch all showtimes
    public List<Showtime> getAllShowtimes() {
        return showtimeDAO.getAllShowtimes();
    }

    // Get showtime by a specific ID
    public Showtime getShowtimeById(int showtimeId) {
        return showtimeDAO.getShowtimeById(showtimeId);
    }

    public void addShowtime(Movie movie, String date, String time) {
        Showtime showtime = new Showtime(movie, date, time);
        showtimeDAO.addShowtime(showtime);

        // Create seats for the showtime
        for (int i = 1; i <= 50; i++) { // Assuming 50 seats per showtime
            Seat seat = new Seat(showtime, i, true); // Seats are available by default
            SeatDAO.saveSeat(seat);
        }

        System.out.println("Showtime and seats added successfully!");
    }

    
    // Get showtimes by a specific movieID
    public List<Showtime> getShowtimesByMovieId(int movieId) {
        return showtimeDAO.getShowtimesByMovieId(movieId);
    }

    
}
